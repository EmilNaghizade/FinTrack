import { View, StyleSheet, Text } from "react-native";
import { router } from "expo-router";

import TransactionForm from "@/components/transaction/TransactionForm";
import { useTransactionStore } from "@/store/transactionStore";
import { colors, spacing } from "@/constants/theme";
import { typography } from "@/styles/typography";
import { TransactionCategory } from "@/types/transaction";

type TransactionFormData = {
  title: string;
  amount: number;
  type: "income" | "expense";
  category: TransactionCategory;
};

export default function AddTransactionScreen() {
  const addTransaction = useTransactionStore((state) => state.addTransaction);

  const handleSave = (data: TransactionFormData) => {
    const newTransaction = {
      id: Date.now().toString(),
      title: data.title,
      amount: data.amount,
      type: data.type,
      category: data.category,
      date: new Date().toISOString(),
    };

    addTransaction(newTransaction);
    router.back();
  };

  return (
    <View style={styles.container}>
      <TransactionForm buttonTitle="Save Transaction" onSubmit={handleSave} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: spacing.lg,
  },
});
