import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";

import { colors, spacing } from "@/constants/theme";
import { fetch as expoFetch } from "expo/fetch";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
} from "firebase/auth";

import { auth } from "@/lib/firebase";

export default function SignInScreen() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);

  const testAuthEndpoint = async () => {
    const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
    const key = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

    if (!url || !key) {
      Alert.alert(
        "Configuration Error",
        "Supabase environment variables are missing.",
      );
      return;
    }

    setTesting(true);

    try {
      console.log("Testing Supabase Auth POST endpoint...");

      const response = await expoFetch(
        `${url}/auth/v1/token?grant_type=password`,
        {
          method: "POST",
          headers: {
            apikey: key,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: "nonexistent-test@example.invalid",
            password: "invalid-test-password",
          }),
        },
      );

      const responseText = await response.text();

      console.log("AUTH POST STATUS:", response.status);
      console.log("AUTH POST BODY:", responseText);

      Alert.alert(
        "Auth Endpoint Test",
        `HTTP Status: ${response.status}\n\n${responseText.slice(0, 250)}`,
      );
    } catch (error) {
      console.error("AUTH POST NETWORK ERROR:", error);

      Alert.alert(
        "Auth Network Error",
        error instanceof Error ? error.message : String(error),
      );
    } finally {
      setTesting(false);
    }
  };

  const handleSubmit = async () => {
    const normalizedEmail = email.trim().toLowerCase();

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      Alert.alert("Invalid Email", "Please enter a valid email address.");
      return;
    }

    if (isSignUp && (!firstName.trim() || !lastName.trim())) {
      Alert.alert(
        "Missing Information",
        "Please enter your first and last name.",
      );
      return;
    }

    if (password.length < 6) {
      Alert.alert(
        "Invalid Password",
        "Password must contain at least 6 characters.",
      );
      return;
    }

    setLoading(true);

    try {
      if (isSignUp) {
        const credential = await createUserWithEmailAndPassword(
          auth,
          normalizedEmail,
          password,
        );

        await updateProfile(credential.user, {
          displayName: `${firstName.trim()} ${lastName.trim()}`,
        });

        console.log("Account created:", credential.user.uid);
      } else {
        const credential = await signInWithEmailAndPassword(
          auth,
          normalizedEmail,
          password,
        );

        console.log("Signed in:", credential.user.uid);
      }
    } catch (error: unknown) {
      const code =
        typeof error === "object" && error !== null && "code" in error
          ? String(error.code)
          : "";

      const messages: Record<string, string> = {
        "auth/email-already-in-use":
          "This email is already registered. Please sign in.",
        "auth/invalid-email": "Please enter a valid email address.",
        "auth/weak-password": "Please choose a stronger password.",
        "auth/invalid-credential": "Incorrect email or password.",
        "auth/network-request-failed":
          "Network error. Please check your connection.",
        "auth/too-many-requests": "Too many attempts. Please try again later.",
      };

      Alert.alert(
        "Authentication Error",
        messages[code] ??
          (error instanceof Error ? error.message : "Something went wrong."),
      );

      console.error("FIREBASE AUTH ERROR:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.logo}>
            <Feather name="trending-up" size={38} color={colors.primary} />
          </View>

          <Text style={styles.brand}>FinTrack</Text>

          <Text style={styles.title}>
            {isSignUp ? "Create an Account" : "Welcome Back"}
          </Text>

          <Text style={styles.subtitle}>
            {isSignUp
              ? "Start taking control of your finances."
              : "Sign in to manage your finances."}
          </Text>

          <View style={styles.form}>
            {isSignUp && (
              <>
                <Text style={styles.label}>First Name</Text>

                <TextInput
                  value={firstName}
                  onChangeText={setFirstName}
                  placeholder="Enter your first name"
                  placeholderTextColor={colors.textSecondary}
                  autoCapitalize="words"
                  autoCorrect={false}
                  style={styles.input}
                  editable={!loading && !testing}
                />

                <Text style={styles.label}>Last Name</Text>

                <TextInput
                  value={lastName}
                  onChangeText={setLastName}
                  placeholder="Enter your last name"
                  placeholderTextColor={colors.textSecondary}
                  autoCapitalize="words"
                  autoCorrect={false}
                  style={styles.input}
                  editable={!loading && !testing}
                />
              </>
            )}

            <Text style={styles.label}>Email</Text>

            <TextInput
              value={email}
              onChangeText={setEmail}
              placeholder="you@example.com"
              placeholderTextColor={colors.textSecondary}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              autoComplete="email"
              textContentType="emailAddress"
              style={styles.input}
              editable={!loading && !testing}
            />

            <Text style={styles.label}>Password</Text>

            <View style={styles.passwordContainer}>
              <TextInput
                value={password}
                onChangeText={setPassword}
                placeholder="Enter your password"
                placeholderTextColor={colors.textSecondary}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
                autoCorrect={false}
                autoComplete={isSignUp ? "new-password" : "current-password"}
                style={styles.passwordInput}
                editable={!loading && !testing}
              />

              <Pressable
                onPress={() => setShowPassword((previous) => !previous)}
                hitSlop={10}
                accessibilityLabel={
                  showPassword ? "Hide password" : "Show password"
                }
              >
                <Feather
                  name={showPassword ? "eye-off" : "eye"}
                  size={20}
                  color={colors.textSecondary}
                />
              </Pressable>
            </View>

            <Pressable
              onPress={handleSubmit}
              disabled={loading || testing}
              style={[
                styles.button,
                (loading || testing) && styles.disabledButton,
              ]}
            >
              {loading ? (
                <ActivityIndicator color="#ffffff" />
              ) : (
                <Text style={styles.buttonText}>
                  {isSignUp ? "Create Account" : "Sign In"}
                </Text>
              )}
            </Pressable>

            <Pressable
              onPress={() => {
                setIsSignUp((previous) => !previous);
                setPassword("");
                setShowPassword(false);
              }}
              disabled={loading || testing}
              style={styles.switchButton}
            >
              <Text style={styles.switchText}>
                {isSignUp
                  ? "Already have an account? Sign In"
                  : "Don't have an account? Sign Up"}
              </Text>
            </Pressable>
          </View>

          <Text style={styles.footer}>Your finances. Your control.</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  keyboardView: {
    flex: 1,
  },
  content: {
    flexGrow: 1,
    justifyContent: "center",
    padding: spacing.xl,
  },
  logo: {
    width: 76,
    height: 76,
    backgroundColor: colors.surface,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    marginBottom: spacing.md,
  },
  brand: {
    color: colors.primary,
    fontSize: 20,
    fontWeight: "700",
    textAlign: "center",
    marginBottom: spacing.xl,
  },
  title: {
    color: colors.text,
    fontSize: 28,
    fontWeight: "700",
    textAlign: "center",
  },
  subtitle: {
    color: colors.textSecondary,
    textAlign: "center",
    fontSize: 14,
    marginTop: spacing.sm,
    marginBottom: spacing.xl,
  },
  form: {
    gap: spacing.md,
  },
  label: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "600",
  },
  input: {
    backgroundColor: colors.surface,
    color: colors.text,
    padding: spacing.md,
    borderRadius: 12,
    fontSize: 16,
  },
  passwordContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surface,
    borderRadius: 12,
    paddingHorizontal: spacing.md,
  },
  passwordInput: {
    flex: 1,
    color: colors.text,
    paddingVertical: spacing.md,
    fontSize: 16,
  },
  button: {
    backgroundColor: colors.primary,
    padding: spacing.md,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    minHeight: 52,
    marginTop: spacing.md,
  },
  disabledButton: {
    opacity: 0.6,
  },
  buttonText: {
    color: "#ffffff",
    fontWeight: "700",
    fontSize: 16,
  },
  switchButton: {
    padding: spacing.md,
    alignItems: "center",
  },
  switchText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: "600",
  },
  testButton: {
    padding: spacing.md,
    alignItems: "center",
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: 12,
  },
  testButtonText: {
    color: colors.primary,
    fontWeight: "600",
    fontSize: 14,
  },
  footer: {
    color: colors.textSecondary,
    fontSize: 12,
    textAlign: "center",
    marginTop: spacing.xl,
  },
});
