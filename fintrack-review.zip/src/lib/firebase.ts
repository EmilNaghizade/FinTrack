import { initializeApp, getApp, getApps } from "firebase/app";

import {
  initializeAuth,
  getAuth,
  getReactNativePersistence,
  type Auth,
} from "firebase/auth";

import AsyncStorage from "@react-native-async-storage/async-storage";

const firebaseConfig = {
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
  authDomain: "fintrack-73b55.firebaseapp.com",
  projectId: "fintrack-73b55",
  storageBucket: "fintrack-73b55.firebasestorage.app",
  messagingSenderId: "913515461703",
  appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID,
};

if (!firebaseConfig.apiKey || !firebaseConfig.appId) {
  throw new Error("Missing Firebase environment variables.");
}

export const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

let authInstance: Auth;

try {
  
  authInstance = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage),
  });

  console.log("[Firebase] Auth initialized with AsyncStorage");
} catch (error: unknown) {
  const errorCode =
    typeof error === "object" && error !== null && "code" in error
      ? String(error.code)
      : undefined;

  if (errorCode === "auth/already-initialized") {
    authInstance = getAuth(app);
    console.log("[Firebase] Reusing existing Auth instance");
  } else {
    console.error("[Firebase] Initialization failed:", error);
    throw error;
  }
}

export const auth = authInstance;
