import "react-native-url-polyfill/auto";

import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient } from "@supabase/supabase-js";
import { AppState, Platform } from "react-native";

let supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;

// Fallback to SUPABASE_URL if not set
if (!supabaseUrl && process.env.SUPABASE_URL) {
  supabaseUrl = process.env.SUPABASE_URL;
}

let supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

// Fallback to SUPABASE_KEY or SUPABASE_SERVICE_ROLE_KEY
if (!supabaseKey) {
  supabaseKey = process.env.SUPABASE_KEY;
}
if (!supabaseKey && process.env.SUPABASE_SERVICE_ROLE_KEY) {
  // Only use service role key for testing - not secure for production
  console.warn("Using service role key - this is insecure for production!");
  supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
}

if (!supabaseUrl || !supabaseKey) {
  throw new Error("Missing Supabase environment variables. Please check your .env file.");
}

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    ...(Platform.OS !== "web" ? { storage: AsyncStorage } : {}),
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

if (Platform.OS !== "web") {
  AppState.addEventListener("change", (state) => {
    if (state === "active") {
      supabase.auth.startAutoRefresh();
    } else {
      supabase.auth.stopAutoRefresh();
    }
  });
}
